const swconf = {
  
    cacheName: 'chirpy-1775723993',resources: [
      '/assets/css/jekyll-theme-chirpy.css',
      '/',
      
        '/categories/',
      
        '/tags/',
      
        '/archives/',
      
        '/about/',
      

      
      
    ],

    interceptor: {paths: [
        
      ],urlPrefixes: [
        
      ]
    },

    purge: false
  
};

